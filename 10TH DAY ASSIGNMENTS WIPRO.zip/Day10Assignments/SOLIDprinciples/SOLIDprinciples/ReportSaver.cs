﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLIDprinciples
{
    public class ReportSaver
    {
        public string SaveReport(string content) { 
            return $"Saved Report {content}";
        }
    }
}
